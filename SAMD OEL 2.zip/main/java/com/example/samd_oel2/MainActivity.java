package com.example.samd_oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText txtusername;
    EditText txtpwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void Signin(View view) {
        txtusername = (EditText) findViewById(R.id.txtusername);
        txtpwd = (EditText) findViewById(R.id.txtpwd);
        if (txtusername.getText().toString().equals("rabia") && txtpwd.getText().toString().equals("rabia")) {
            Intent i=new Intent(MainActivity.this,Dashboard.class);
            startActivity(i);
        } else
        {
            txtusername.setError("Error! Something is not correct");
            txtpwd.setError("Error! Something is not correct");
        }
    }
}