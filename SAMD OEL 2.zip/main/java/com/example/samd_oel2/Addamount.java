package com.example.samd_oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class Addamount extends AppCompatActivity {
    EditText edtnotify = (EditText)findViewById(R.id.edtnotify);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addamount);
    }

    public void Notify(View view) {
        edtnotify.setText("Your amount has been added successfully !");
    }
}