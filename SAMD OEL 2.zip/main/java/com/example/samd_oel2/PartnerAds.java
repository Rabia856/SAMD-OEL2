package com.example.samd_oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class PartnerAds extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_partner_ads);

        VideoView videoview=(VideoView) findViewById(R.id.video_view);
        String videoPath="android/resource://"+getPackageName()+"/"+R.raw.video;
        Uri uri=Uri.parse(videoPath);
        videoview.setVideoURI(uri);

        MediaController mediacontroller=new MediaController(this);
        videoview.setMediaController(mediacontroller);
        mediacontroller.setAnchorView(videoview);
    }
}