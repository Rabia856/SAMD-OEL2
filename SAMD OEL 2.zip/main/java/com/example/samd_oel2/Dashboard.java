package com.example.samd_oel2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Dashboard extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
    }

    public void Userprofile(View view) {
        Intent i=new Intent(Dashboard.this,Userprofile.class);
        startActivity(i);
    }

    public void Addamount(View view) {
        Intent i=new Intent(Dashboard.this,Addamount.class);
        startActivity(i);
    }

    public void Transferamount(View view) {
        Intent i=new Intent(Dashboard.this,Transferamount.class);
        startActivity(i);
    }

    public void PartnerAds(View view) {
        Intent i=new Intent(Dashboard.this,PartnerAds.class);
        startActivity(i);
    }
}